#!/bin/bash
# shellcheck shell=bash

DEBUG=false
trap 'echo -e "\n[updater] Stopped."; exit 0' INT

# Usage: updater.sh <folder-to-sync> [name-of-command]
if [[ -z $1 ]]; then
      echo "Usage: $0 <folder-to-sync> [name-of-command]"
      exit 1
fi

srcfolder="$1"
filename="$srcfolder/main.sh"
basename="$(basename "$srcfolder")"
cmd="${2:-$basename}"

mkdir -p ~/src ~/bin

while true; do
      if [[ ! -f "$filename" ]]; then
            echo "File $filename does not exist. Exiting..."
            exit 1
      fi

      [[ "$DEBUG" = true ]] && echo "[DEBUG]: filename=$filename" && echo "[DEBUG]: cmd=$cmd"

      dst_src="$HOME/src/$basename/src/$cmd"
      dst_bin="$HOME/src/$basename/bin/$cmd"
      dst_final="$HOME/bin/$cmd"

      mkdir -p "$(dirname "$dst_src")" "$(dirname "$dst_bin")"

      if cmp -s "$filename" "$dst_src"; then
            if [[ "$DEBUG" = true ]]; then
                  echo "[DEBUG]: No changes detected. Skipping..."
            fi
            printf "\r[$(date '+%H:%M:%S')] Watching \033[0;32m%s\033[0m..." "$filename"
            sleep 1
            continue
      else
            if [[ "$DEBUG" = true ]]; then
                  echo "[$(date '+%H:%M:%S')] Changes detected. Syncing..."
            fi
            cp "$filename" "$dst_src"
            chmod +x "$dst_src"

            shc -o "$dst_bin" -f "$dst_src"
            ditto "$dst_bin" "$dst_final"
            echo "[$(date '+%H:%M:%S')] Updated $dst_final"
      fi

      sleep 1
done
